# Use Case diagram

![BPO Use case](https://github.com/user-attachments/assets/6bf21611-9ed4-4775-9485-16f2769432a2)

# Activity Diagram

![BPO - Activity diagram](https://github.com/user-attachments/assets/e8dcbeb8-eb5b-49d0-9aa5-9ee35844fdeb)

# Class Diagram

![BPO - Class](https://github.com/user-attachments/assets/a96ce12e-98e4-4ff1-aac7-2b6ef2b6937b)
